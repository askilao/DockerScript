<?php
$dbhost = "10.10.0.200";
$dbport = "3306";
$db = "bookface";
$dbuser = "superuser";
$dbpassw = "greatpw";
$webhost = "10.212.136.60";
$weburl = 'http://' . $webhost ;
$memcache_enabled = 1;
$memcache_enabled_pictures = 1;
$memcache_server = "10.10.0.175";

?>
