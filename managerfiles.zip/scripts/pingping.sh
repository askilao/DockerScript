#!/bin/bash

while IFS= read -r ip; do
	if ping -q -c2 "$ip" &>/dev/null; then
		echo "$ip fikk svar"
	else
		echo "$ip fikk ikke svar"
	fi
done <"$HOME"/scripts/iplist.txt

